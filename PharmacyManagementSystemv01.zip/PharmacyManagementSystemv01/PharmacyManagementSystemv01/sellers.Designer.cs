﻿namespace PharmacyManagementSystemv01
{
    partial class sellers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sellers));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnSelling = new System.Windows.Forms.Button();
            this.btnSellers = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnMedicine = new System.Windows.Forms.Button();
            this.btnmanufacture = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DGVSeller = new System.Windows.Forms.DataGridView();
            this.btnsellerDelete = new System.Windows.Forms.Button();
            this.btnsellerupdate = new System.Windows.Forms.Button();
            this.btnsellersave = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePickerSeller = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBoxGenderSeller = new System.Windows.Forms.ComboBox();
            this.txtBoxSellerMobile = new System.Windows.Forms.TextBox();
            this.txtBoxSelleraddress = new System.Windows.Forms.TextBox();
            this.txtBoxsellername = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxSellerpwd = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSeller)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnSelling);
            this.panel1.Controls.Add(this.btnSellers);
            this.panel1.Controls.Add(this.btnCustomer);
            this.panel1.Controls.Add(this.btnMedicine);
            this.panel1.Controls.Add(this.btnmanufacture);
            this.panel1.Controls.Add(this.btnDashboard);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 761);
            this.panel1.TabIndex = 29;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.White;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnLogout.Location = new System.Drawing.Point(97, 709);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(133, 39);
            this.btnLogout.TabIndex = 19;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnSelling
            // 
            this.btnSelling.BackColor = System.Drawing.Color.White;
            this.btnSelling.FlatAppearance.BorderSize = 0;
            this.btnSelling.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelling.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSelling.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnSelling.Location = new System.Drawing.Point(86, 540);
            this.btnSelling.Name = "btnSelling";
            this.btnSelling.Size = new System.Drawing.Size(144, 39);
            this.btnSelling.TabIndex = 19;
            this.btnSelling.Text = "Selling";
            this.btnSelling.UseVisualStyleBackColor = false;
            // 
            // btnSellers
            // 
            this.btnSellers.BackColor = System.Drawing.Color.LimeGreen;
            this.btnSellers.FlatAppearance.BorderSize = 0;
            this.btnSellers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSellers.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSellers.ForeColor = System.Drawing.Color.White;
            this.btnSellers.Location = new System.Drawing.Point(86, 455);
            this.btnSellers.Name = "btnSellers";
            this.btnSellers.Size = new System.Drawing.Size(144, 39);
            this.btnSellers.TabIndex = 19;
            this.btnSellers.Text = "Sellers";
            this.btnSellers.UseVisualStyleBackColor = false;
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackColor = System.Drawing.Color.White;
            this.btnCustomer.FlatAppearance.BorderSize = 0;
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomer.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCustomer.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnCustomer.Location = new System.Drawing.Point(86, 396);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(144, 39);
            this.btnCustomer.TabIndex = 19;
            this.btnCustomer.Text = "Customers";
            this.btnCustomer.UseVisualStyleBackColor = false;
            // 
            // btnMedicine
            // 
            this.btnMedicine.BackColor = System.Drawing.Color.White;
            this.btnMedicine.FlatAppearance.BorderSize = 0;
            this.btnMedicine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedicine.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMedicine.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnMedicine.Location = new System.Drawing.Point(86, 320);
            this.btnMedicine.Name = "btnMedicine";
            this.btnMedicine.Size = new System.Drawing.Size(144, 39);
            this.btnMedicine.TabIndex = 19;
            this.btnMedicine.Text = "Medicine";
            this.btnMedicine.UseVisualStyleBackColor = false;
            // 
            // btnmanufacture
            // 
            this.btnmanufacture.BackColor = System.Drawing.Color.White;
            this.btnmanufacture.FlatAppearance.BorderSize = 0;
            this.btnmanufacture.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmanufacture.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnmanufacture.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnmanufacture.Location = new System.Drawing.Point(86, 237);
            this.btnmanufacture.Name = "btnmanufacture";
            this.btnmanufacture.Size = new System.Drawing.Size(144, 39);
            this.btnmanufacture.TabIndex = 19;
            this.btnmanufacture.Text = "Manufacture";
            this.btnmanufacture.UseVisualStyleBackColor = false;
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.White;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDashboard.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnDashboard.Location = new System.Drawing.Point(86, 158);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(144, 39);
            this.btnDashboard.TabIndex = 19;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Corner";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(71, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Med";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(12, 683);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(80, 75);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(3, 522);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(80, 75);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(3, 441);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(80, 75);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(3, 374);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(80, 75);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, 298);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(80, 75);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(3, 217);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(80, 75);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 136);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(80, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(91, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // DGVSeller
            // 
            this.DGVSeller.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.DGVSeller.BackgroundColor = System.Drawing.Color.White;
            this.DGVSeller.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSeller.GridColor = System.Drawing.Color.Black;
            this.DGVSeller.Location = new System.Drawing.Point(18, 287);
            this.DGVSeller.Name = "DGVSeller";
            this.DGVSeller.RowHeadersWidth = 51;
            this.DGVSeller.RowTemplate.Height = 29;
            this.DGVSeller.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVSeller.Size = new System.Drawing.Size(950, 329);
            this.DGVSeller.TabIndex = 25;
            // 
            // btnsellerDelete
            // 
            this.btnsellerDelete.BackColor = System.Drawing.Color.LimeGreen;
            this.btnsellerDelete.FlatAppearance.BorderSize = 0;
            this.btnsellerDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsellerDelete.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsellerDelete.ForeColor = System.Drawing.Color.White;
            this.btnsellerDelete.Location = new System.Drawing.Point(567, 203);
            this.btnsellerDelete.Name = "btnsellerDelete";
            this.btnsellerDelete.Size = new System.Drawing.Size(94, 39);
            this.btnsellerDelete.TabIndex = 24;
            this.btnsellerDelete.Text = "Delete";
            this.btnsellerDelete.UseVisualStyleBackColor = false;
            // 
            // btnsellerupdate
            // 
            this.btnsellerupdate.BackColor = System.Drawing.Color.LimeGreen;
            this.btnsellerupdate.FlatAppearance.BorderSize = 0;
            this.btnsellerupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsellerupdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsellerupdate.ForeColor = System.Drawing.Color.White;
            this.btnsellerupdate.Location = new System.Drawing.Point(448, 203);
            this.btnsellerupdate.Name = "btnsellerupdate";
            this.btnsellerupdate.Size = new System.Drawing.Size(94, 39);
            this.btnsellerupdate.TabIndex = 24;
            this.btnsellerupdate.Text = "Update";
            this.btnsellerupdate.UseVisualStyleBackColor = false;
            // 
            // btnsellersave
            // 
            this.btnsellersave.BackColor = System.Drawing.Color.LimeGreen;
            this.btnsellersave.FlatAppearance.BorderSize = 0;
            this.btnsellersave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsellersave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsellersave.ForeColor = System.Drawing.Color.White;
            this.btnsellersave.Location = new System.Drawing.Point(335, 203);
            this.btnsellersave.Name = "btnsellersave";
            this.btnsellersave.Size = new System.Drawing.Size(94, 39);
            this.btnsellersave.TabIndex = 24;
            this.btnsellersave.Text = "Save";
            this.btnsellersave.UseVisualStyleBackColor = false;
            // 
            // btnclose
            // 
            this.btnclose.Image = ((System.Drawing.Image)(resources.GetObject("btnclose.Image")));
            this.btnclose.Location = new System.Drawing.Point(1230, 0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(50, 50);
            this.btnclose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnclose.TabIndex = 32;
            this.btnclose.TabStop = false;
            this.btnclose.UseWaitCursor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(273, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 27);
            this.label5.TabIndex = 30;
            this.label5.Text = "Sellers";
            // 
            // dateTimePickerSeller
            // 
            this.dateTimePickerSeller.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerSeller.Location = new System.Drawing.Point(659, 76);
            this.dateTimePickerSeller.Name = "dateTimePickerSeller";
            this.dateTimePickerSeller.Size = new System.Drawing.Size(155, 32);
            this.dateTimePickerSeller.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 27);
            this.label3.TabIndex = 20;
            this.label3.Text = "Seller Details";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.comboBoxGenderSeller);
            this.panel2.Controls.Add(this.DGVSeller);
            this.panel2.Controls.Add(this.btnsellerDelete);
            this.panel2.Controls.Add(this.btnsellerupdate);
            this.panel2.Controls.Add(this.btnsellersave);
            this.panel2.Controls.Add(this.dateTimePickerSeller);
            this.panel2.Controls.Add(this.txtBoxSellerMobile);
            this.panel2.Controls.Add(this.txtBoxSelleraddress);
            this.panel2.Controls.Add(this.textBoxSellerpwd);
            this.panel2.Controls.Add(this.txtBoxsellername);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(273, 117);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(995, 631);
            this.panel2.TabIndex = 28;
            // 
            // comboBoxGenderSeller
            // 
            this.comboBoxGenderSeller.FormattingEnabled = true;
            this.comboBoxGenderSeller.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxGenderSeller.Location = new System.Drawing.Point(833, 76);
            this.comboBoxGenderSeller.Name = "comboBoxGenderSeller";
            this.comboBoxGenderSeller.Size = new System.Drawing.Size(151, 31);
            this.comboBoxGenderSeller.TabIndex = 26;
            // 
            // txtBoxSellerMobile
            // 
            this.txtBoxSellerMobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxSellerMobile.Location = new System.Drawing.Point(460, 75);
            this.txtBoxSellerMobile.Name = "txtBoxSellerMobile";
            this.txtBoxSellerMobile.Size = new System.Drawing.Size(183, 32);
            this.txtBoxSellerMobile.TabIndex = 21;
            // 
            // txtBoxSelleraddress
            // 
            this.txtBoxSelleraddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxSelleraddress.Location = new System.Drawing.Point(241, 75);
            this.txtBoxSelleraddress.Multiline = true;
            this.txtBoxSelleraddress.Name = "txtBoxSelleraddress";
            this.txtBoxSelleraddress.Size = new System.Drawing.Size(201, 106);
            this.txtBoxSelleraddress.TabIndex = 21;
            // 
            // txtBoxsellername
            // 
            this.txtBoxsellername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxsellername.Location = new System.Drawing.Point(18, 76);
            this.txtBoxsellername.Name = "txtBoxsellername";
            this.txtBoxsellername.Size = new System.Drawing.Size(202, 32);
            this.txtBoxsellername.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(460, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(183, 27);
            this.label9.TabIndex = 20;
            this.label9.Text = "Mobile number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(659, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(147, 27);
            this.label8.TabIndex = 20;
            this.label8.Text = "Date of birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(241, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 27);
            this.label7.TabIndex = 20;
            this.label7.Text = "Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(18, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 27);
            this.label10.TabIndex = 20;
            this.label10.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(833, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 27);
            this.label6.TabIndex = 20;
            this.label6.Text = "Gender";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(335, 257);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 27);
            this.label11.TabIndex = 20;
            this.label11.Text = "Seller List";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(448, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(613, 34);
            this.label4.TabIndex = 31;
            this.label4.Text = "Med corner Pharmacy Management System";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(18, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 27);
            this.label12.TabIndex = 20;
            this.label12.Text = "Password";
            // 
            // textBoxSellerpwd
            // 
            this.textBoxSellerpwd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSellerpwd.Location = new System.Drawing.Point(18, 150);
            this.textBoxSellerpwd.Name = "textBoxSellerpwd";
            this.textBoxSellerpwd.PasswordChar = '*';
            this.textBoxSellerpwd.Size = new System.Drawing.Size(202, 32);
            this.textBoxSellerpwd.TabIndex = 21;
            // 
            // sellers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LimeGreen;
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "sellers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "sellers";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSeller)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private Button btnLogout;
        private Button btnSelling;
        private Button btnSellers;
        private Button btnCustomer;
        private Button btnMedicine;
        private Button btnmanufacture;
        private Button btnDashboard;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private DataGridView DGVSeller;
        private Button btnsellerDelete;
        private Button btnsellerupdate;
        private Button btnsellersave;
        private PictureBox btnclose;
        private Label label5;
        private DateTimePicker dateTimePickerSeller;
        private Label label3;
        private Panel panel2;
        private ComboBox comboBoxGenderSeller;
        private TextBox txtBoxSellerMobile;
        private TextBox txtBoxSelleraddress;
        private TextBox textBoxSellerpwd;
        private TextBox txtBoxsellername;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label12;
        private Label label10;
        private Label label6;
        private Label label11;
        private Label label4;
    }
}