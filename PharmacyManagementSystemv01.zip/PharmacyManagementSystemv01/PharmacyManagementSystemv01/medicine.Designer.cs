﻿namespace PharmacyManagementSystemv01
{
    partial class medicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(medicine));
            this.btnMedDelete = new System.Windows.Forms.Button();
            this.btnMedupdate = new System.Windows.Forms.Button();
            this.btnMedsave = new System.Windows.Forms.Button();
            this.txtBoxMedMfID = new System.Windows.Forms.TextBox();
            this.txtBoxMedQty = new System.Windows.Forms.TextBox();
            this.txtBoxMedname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnSelling = new System.Windows.Forms.Button();
            this.btnSellers = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMedicine = new System.Windows.Forms.Button();
            this.btnmanufacture = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DGVMedicine = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxmedType = new System.Windows.Forms.ComboBox();
            this.txtBoxMedrate = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBoxMedMfname = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVMedicine)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMedDelete
            // 
            this.btnMedDelete.BackColor = System.Drawing.Color.LimeGreen;
            this.btnMedDelete.FlatAppearance.BorderSize = 0;
            this.btnMedDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedDelete.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMedDelete.ForeColor = System.Drawing.Color.White;
            this.btnMedDelete.Location = new System.Drawing.Point(567, 203);
            this.btnMedDelete.Name = "btnMedDelete";
            this.btnMedDelete.Size = new System.Drawing.Size(94, 39);
            this.btnMedDelete.TabIndex = 24;
            this.btnMedDelete.Text = "Delete";
            this.btnMedDelete.UseVisualStyleBackColor = false;
            // 
            // btnMedupdate
            // 
            this.btnMedupdate.BackColor = System.Drawing.Color.LimeGreen;
            this.btnMedupdate.FlatAppearance.BorderSize = 0;
            this.btnMedupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedupdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMedupdate.ForeColor = System.Drawing.Color.White;
            this.btnMedupdate.Location = new System.Drawing.Point(448, 203);
            this.btnMedupdate.Name = "btnMedupdate";
            this.btnMedupdate.Size = new System.Drawing.Size(94, 39);
            this.btnMedupdate.TabIndex = 24;
            this.btnMedupdate.Text = "Update";
            this.btnMedupdate.UseVisualStyleBackColor = false;
            // 
            // btnMedsave
            // 
            this.btnMedsave.BackColor = System.Drawing.Color.LimeGreen;
            this.btnMedsave.FlatAppearance.BorderSize = 0;
            this.btnMedsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedsave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMedsave.ForeColor = System.Drawing.Color.White;
            this.btnMedsave.Location = new System.Drawing.Point(335, 203);
            this.btnMedsave.Name = "btnMedsave";
            this.btnMedsave.Size = new System.Drawing.Size(94, 39);
            this.btnMedsave.TabIndex = 24;
            this.btnMedsave.Text = "Save";
            this.btnMedsave.UseVisualStyleBackColor = false;
            // 
            // txtBoxMedMfID
            // 
            this.txtBoxMedMfID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMedMfID.Location = new System.Drawing.Point(589, 75);
            this.txtBoxMedMfID.Name = "txtBoxMedMfID";
            this.txtBoxMedMfID.Size = new System.Drawing.Size(143, 32);
            this.txtBoxMedMfID.TabIndex = 21;
            // 
            // txtBoxMedQty
            // 
            this.txtBoxMedQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMedQty.Location = new System.Drawing.Point(318, 75);
            this.txtBoxMedQty.Name = "txtBoxMedQty";
            this.txtBoxMedQty.Size = new System.Drawing.Size(136, 32);
            this.txtBoxMedQty.TabIndex = 21;
            // 
            // txtBoxMedname
            // 
            this.txtBoxMedname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMedname.Location = new System.Drawing.Point(18, 76);
            this.txtBoxMedname.Name = "txtBoxMedname";
            this.txtBoxMedname.Size = new System.Drawing.Size(134, 32);
            this.txtBoxMedname.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(460, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 27);
            this.label9.TabIndex = 20;
            this.label9.Text = "Rate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(579, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(183, 27);
            this.label8.TabIndex = 20;
            this.label8.Text = "Manufacture ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(18, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 27);
            this.label6.TabIndex = 20;
            this.label6.Text = "Name";
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.White;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnLogout.Location = new System.Drawing.Point(97, 709);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(133, 39);
            this.btnLogout.TabIndex = 19;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnSelling
            // 
            this.btnSelling.BackColor = System.Drawing.Color.White;
            this.btnSelling.FlatAppearance.BorderSize = 0;
            this.btnSelling.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelling.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSelling.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnSelling.Location = new System.Drawing.Point(86, 540);
            this.btnSelling.Name = "btnSelling";
            this.btnSelling.Size = new System.Drawing.Size(144, 39);
            this.btnSelling.TabIndex = 19;
            this.btnSelling.Text = "Selling";
            this.btnSelling.UseVisualStyleBackColor = false;
            // 
            // btnSellers
            // 
            this.btnSellers.BackColor = System.Drawing.Color.White;
            this.btnSellers.FlatAppearance.BorderSize = 0;
            this.btnSellers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSellers.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSellers.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnSellers.Location = new System.Drawing.Point(86, 455);
            this.btnSellers.Name = "btnSellers";
            this.btnSellers.Size = new System.Drawing.Size(144, 39);
            this.btnSellers.TabIndex = 19;
            this.btnSellers.Text = "Sellers";
            this.btnSellers.UseVisualStyleBackColor = false;
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackColor = System.Drawing.Color.White;
            this.btnCustomer.FlatAppearance.BorderSize = 0;
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomer.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCustomer.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnCustomer.Location = new System.Drawing.Point(86, 396);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(144, 39);
            this.btnCustomer.TabIndex = 19;
            this.btnCustomer.Text = "Customers";
            this.btnCustomer.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(335, 257);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(158, 27);
            this.label11.TabIndex = 20;
            this.label11.Text = "Medicine List";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnSelling);
            this.panel1.Controls.Add(this.btnSellers);
            this.panel1.Controls.Add(this.btnCustomer);
            this.panel1.Controls.Add(this.btnMedicine);
            this.panel1.Controls.Add(this.btnmanufacture);
            this.panel1.Controls.Add(this.btnDashboard);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 761);
            this.panel1.TabIndex = 24;
            // 
            // btnMedicine
            // 
            this.btnMedicine.BackColor = System.Drawing.Color.LimeGreen;
            this.btnMedicine.FlatAppearance.BorderSize = 0;
            this.btnMedicine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedicine.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMedicine.ForeColor = System.Drawing.Color.White;
            this.btnMedicine.Location = new System.Drawing.Point(86, 320);
            this.btnMedicine.Name = "btnMedicine";
            this.btnMedicine.Size = new System.Drawing.Size(144, 39);
            this.btnMedicine.TabIndex = 19;
            this.btnMedicine.Text = "Medicine";
            this.btnMedicine.UseVisualStyleBackColor = false;
            // 
            // btnmanufacture
            // 
            this.btnmanufacture.BackColor = System.Drawing.Color.White;
            this.btnmanufacture.FlatAppearance.BorderSize = 0;
            this.btnmanufacture.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmanufacture.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnmanufacture.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnmanufacture.Location = new System.Drawing.Point(86, 237);
            this.btnmanufacture.Name = "btnmanufacture";
            this.btnmanufacture.Size = new System.Drawing.Size(144, 39);
            this.btnmanufacture.TabIndex = 19;
            this.btnmanufacture.Text = "Manufacture";
            this.btnmanufacture.UseVisualStyleBackColor = false;
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.White;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDashboard.ForeColor = System.Drawing.Color.LimeGreen;
            this.btnDashboard.Location = new System.Drawing.Point(86, 158);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(144, 39);
            this.btnDashboard.TabIndex = 19;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Corner";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(71, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Med";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(12, 683);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(80, 75);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(3, 522);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(80, 75);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(3, 441);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(80, 75);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(3, 374);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(80, 75);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, 298);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(80, 75);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(3, 217);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(80, 75);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 136);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(80, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(91, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(318, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 27);
            this.label7.TabIndex = 20;
            this.label7.Text = "Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(273, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 27);
            this.label5.TabIndex = 25;
            this.label5.Text = "Medicines";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 27);
            this.label3.TabIndex = 20;
            this.label3.Text = "Medicine Details";
            // 
            // btnclose
            // 
            this.btnclose.Image = ((System.Drawing.Image)(resources.GetObject("btnclose.Image")));
            this.btnclose.Location = new System.Drawing.Point(1230, 0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(50, 50);
            this.btnclose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnclose.TabIndex = 27;
            this.btnclose.TabStop = false;
            this.btnclose.UseWaitCursor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.DGVMedicine);
            this.panel2.Controls.Add(this.btnMedDelete);
            this.panel2.Controls.Add(this.btnMedupdate);
            this.panel2.Controls.Add(this.btnMedsave);
            this.panel2.Controls.Add(this.comboBoxmedType);
            this.panel2.Controls.Add(this.txtBoxMedrate);
            this.panel2.Controls.Add(this.txtBoxMedMfname);
            this.panel2.Controls.Add(this.txtBoxMedMfID);
            this.panel2.Controls.Add(this.txtBoxMedQty);
            this.panel2.Controls.Add(this.txtBoxMedname);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(273, 117);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(995, 631);
            this.panel2.TabIndex = 23;
            // 
            // DGVMedicine
            // 
            this.DGVMedicine.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.DGVMedicine.BackgroundColor = System.Drawing.Color.White;
            this.DGVMedicine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVMedicine.GridColor = System.Drawing.Color.Black;
            this.DGVMedicine.Location = new System.Drawing.Point(18, 287);
            this.DGVMedicine.Name = "DGVMedicine";
            this.DGVMedicine.RowHeadersWidth = 51;
            this.DGVMedicine.RowTemplate.Height = 29;
            this.DGVMedicine.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVMedicine.Size = new System.Drawing.Size(950, 329);
            this.DGVMedicine.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(448, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(613, 34);
            this.label4.TabIndex = 26;
            this.label4.Text = "Med corner Pharmacy Management System";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(175, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 27);
            this.label12.TabIndex = 20;
            this.label12.Text = "Type";
            // 
            // comboBoxmedType
            // 
            this.comboBoxmedType.FormattingEnabled = true;
            this.comboBoxmedType.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxmedType.Location = new System.Drawing.Point(175, 77);
            this.comboBoxmedType.Name = "comboBoxmedType";
            this.comboBoxmedType.Size = new System.Drawing.Size(131, 31);
            this.comboBoxmedType.TabIndex = 23;
            // 
            // txtBoxMedrate
            // 
            this.txtBoxMedrate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMedrate.Location = new System.Drawing.Point(460, 75);
            this.txtBoxMedrate.Name = "txtBoxMedrate";
            this.txtBoxMedrate.Size = new System.Drawing.Size(110, 32);
            this.txtBoxMedrate.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(768, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(227, 27);
            this.label10.TabIndex = 20;
            this.label10.Text = "Manufacture name";
            // 
            // txtBoxMedMfname
            // 
            this.txtBoxMedMfname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMedMfname.Location = new System.Drawing.Point(778, 75);
            this.txtBoxMedMfname.Name = "txtBoxMedMfname";
            this.txtBoxMedMfname.Size = new System.Drawing.Size(195, 32);
            this.txtBoxMedMfname.TabIndex = 21;
            // 
            // medicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LimeGreen;
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "medicine";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "medicine";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnclose)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVMedicine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnMedDelete;
        private Button btnMedupdate;
        private Button btnMedsave;
        private TextBox txtBoxMedMfID;
        private TextBox txtBoxMedQty;
        private TextBox txtBoxMedname;
        private Label label9;
        private Label label8;
        private Label label6;
        private Button btnLogout;
        private Button btnSelling;
        private Button btnSellers;
        private Button btnCustomer;
        private Label label11;
        private Panel panel1;
        private Button btnMedicine;
        private Button btnmanufacture;
        private Button btnDashboard;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label7;
        private Label label5;
        private Label label3;
        private PictureBox btnclose;
        private Panel panel2;
        private DataGridView DGVMedicine;
        private ComboBox comboBoxmedType;
        private TextBox txtBoxMedrate;
        private TextBox txtBoxMedMfname;
        private Label label12;
        private Label label10;
        private Label label4;
    }
}